<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Editor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Editor))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("No DataBase", 0, 0)
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("LBound")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("UBound")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Array", New System.Windows.Forms.TreeNode() {TreeNode2, TreeNode3})
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Asc")
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CBool")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CByte")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CCur")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CDate")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CDbl")
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CDec")
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chr")
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chr$")
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CInt")
        Dim TreeNode15 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Clng")
        Dim TreeNode16 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CSng")
        Dim TreeNode17 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CStr")
        Dim TreeNode18 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CVar")
        Dim TreeNode19 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CVDate")
        Dim TreeNode20 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DateSerial")
        Dim TreeNode21 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DateValue")
        Dim TreeNode22 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Day")
        Dim TreeNode23 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("FormatCurrency")
        Dim TreeNode24 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("FormatDateTime")
        Dim TreeNode25 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("FormatNumber")
        Dim TreeNode26 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("FormatPercent")
        Dim TreeNode27 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("GUIDFromString")
        Dim TreeNode28 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Hex")
        Dim TreeNode29 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode(" Hex$")
        Dim TreeNode30 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Hour")
        Dim TreeNode31 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Minute")
        Dim TreeNode32 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Month")
        Dim TreeNode33 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nz")
        Dim TreeNode34 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Oct")
        Dim TreeNode35 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Oct$")
        Dim TreeNode36 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Second")
        Dim TreeNode37 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Str")
        Dim TreeNode38 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Str$")
        Dim TreeNode39 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StrConv")
        Dim TreeNode40 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StringFromGUID")
        Dim TreeNode41 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("TimeSerial")
        Dim TreeNode42 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("TimeValue")
        Dim TreeNode43 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Val")
        Dim TreeNode44 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Weekday")
        Dim TreeNode45 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Year")
        Dim TreeNode46 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Conversion", New System.Windows.Forms.TreeNode() {TreeNode5, TreeNode6, TreeNode7, TreeNode8, TreeNode9, TreeNode10, TreeNode11, TreeNode12, TreeNode13, TreeNode14, TreeNode15, TreeNode16, TreeNode17, TreeNode18, TreeNode19, TreeNode20, TreeNode21, TreeNode22, TreeNode23, TreeNode24, TreeNode25, TreeNode26, TreeNode27, TreeNode28, TreeNode29, TreeNode30, TreeNode31, TreeNode32, TreeNode33, TreeNode34, TreeNode35, TreeNode36, TreeNode37, TreeNode38, TreeNode39, TreeNode40, TreeNode41, TreeNode42, TreeNode43, TreeNode44, TreeNode45})
        Dim TreeNode47 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CurrentUser")
        Dim TreeNode48 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Eval")
        Dim TreeNode49 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("HyperlinkPart")
        Dim TreeNode50 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IMEStatus")
        Dim TreeNode51 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Partition")
        Dim TreeNode52 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DataBase", New System.Windows.Forms.TreeNode() {TreeNode47, TreeNode48, TreeNode49, TreeNode50, TreeNode51})
        Dim TreeNode53 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CDate")
        Dim TreeNode54 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CVDate")
        Dim TreeNode55 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Date")
        Dim TreeNode56 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Date$")
        Dim TreeNode57 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DateAdd")
        Dim TreeNode58 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DateDiff")
        Dim TreeNode59 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DatePart")
        Dim TreeNode60 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DateSerial")
        Dim TreeNode61 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DateValue")
        Dim TreeNode62 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Day")
        Dim TreeNode63 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Hour")
        Dim TreeNode64 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsDate")
        Dim TreeNode65 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Minute")
        Dim TreeNode66 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Month")
        Dim TreeNode67 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("MonthName")
        Dim TreeNode68 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Now")
        Dim TreeNode69 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Second")
        Dim TreeNode70 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Time")
        Dim TreeNode71 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Time$")
        Dim TreeNode72 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Timer")
        Dim TreeNode73 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("TimeSerial")
        Dim TreeNode74 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("TimeValue")
        Dim TreeNode75 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Weekday")
        Dim TreeNode76 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("WeekdayName")
        Dim TreeNode77 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Year")
        Dim TreeNode78 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Date/Time", New System.Windows.Forms.TreeNode() {TreeNode53, TreeNode54, TreeNode55, TreeNode56, TreeNode57, TreeNode58, TreeNode59, TreeNode60, TreeNode61, TreeNode62, TreeNode63, TreeNode64, TreeNode65, TreeNode66, TreeNode67, TreeNode68, TreeNode69, TreeNode70, TreeNode71, TreeNode72, TreeNode73, TreeNode74, TreeNode75, TreeNode76, TreeNode77})
        Dim TreeNode79 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DAvg")
        Dim TreeNode80 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DCount")
        Dim TreeNode81 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DFirst")
        Dim TreeNode82 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DLast")
        Dim TreeNode83 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DLookup")
        Dim TreeNode84 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DMax")
        Dim TreeNode85 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DMin")
        Dim TreeNode86 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DStDev")
        Dim TreeNode87 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DSum")
        Dim TreeNode88 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DVar")
        Dim TreeNode89 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DVarP")
        Dim TreeNode90 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Domain Aggregatte", New System.Windows.Forms.TreeNode() {TreeNode79, TreeNode80, TreeNode81, TreeNode82, TreeNode83, TreeNode84, TreeNode85, TreeNode86, TreeNode87, TreeNode88, TreeNode89})
        Dim TreeNode91 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("CVErr")
        Dim TreeNode92 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Err")
        Dim TreeNode93 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Error")
        Dim TreeNode94 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Error$")
        Dim TreeNode95 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsError")
        Dim TreeNode96 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Error Handling", New System.Windows.Forms.TreeNode() {TreeNode91, TreeNode92, TreeNode93, TreeNode94, TreeNode95})
        Dim TreeNode97 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("DDB")
        Dim TreeNode98 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("FV")
        Dim TreeNode99 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IPmt")
        Dim TreeNode100 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IRR")
        Dim TreeNode101 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("MIRR")
        Dim TreeNode102 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("NPer")
        Dim TreeNode103 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("NPV")
        Dim TreeNode104 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Pmt")
        Dim TreeNode105 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("PPmt")
        Dim TreeNode106 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("PV")
        Dim TreeNode107 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Rate")
        Dim TreeNode108 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("SLN")
        Dim TreeNode109 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("SYD")
        Dim TreeNode110 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Financial", New System.Windows.Forms.TreeNode() {TreeNode97, TreeNode98, TreeNode99, TreeNode100, TreeNode101, TreeNode102, TreeNode103, TreeNode104, TreeNode105, TreeNode106, TreeNode107, TreeNode108, TreeNode109})
        Dim TreeNode111 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsArray")
        Dim TreeNode112 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsDate")
        Dim TreeNode113 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsEmpty")
        Dim TreeNode114 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsError")
        Dim TreeNode115 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsMissing")
        Dim TreeNode116 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsNull")
        Dim TreeNode117 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsNumeric")
        Dim TreeNode118 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IsObject")
        Dim TreeNode119 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("TypeName")
        Dim TreeNode120 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("VarType")
        Dim TreeNode121 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Inspection", New System.Windows.Forms.TreeNode() {TreeNode111, TreeNode112, TreeNode113, TreeNode114, TreeNode115, TreeNode116, TreeNode117, TreeNode118, TreeNode119, TreeNode120})
        Dim TreeNode122 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Abs")
        Dim TreeNode123 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Atn")
        Dim TreeNode124 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cos")
        Dim TreeNode125 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Exp")
        Dim TreeNode126 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Fix")
        Dim TreeNode127 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Int")
        Dim TreeNode128 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Log")
        Dim TreeNode129 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Rnd")
        Dim TreeNode130 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Round")
        Dim TreeNode131 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sgn")
        Dim TreeNode132 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sin")
        Dim TreeNode133 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sqr")
        Dim TreeNode134 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Tan")
        Dim TreeNode135 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Math", New System.Windows.Forms.TreeNode() {TreeNode122, TreeNode123, TreeNode124, TreeNode125, TreeNode126, TreeNode127, TreeNode128, TreeNode129, TreeNode130, TreeNode131, TreeNode132, TreeNode133, TreeNode134})
        Dim TreeNode136 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Choose")
        Dim TreeNode137 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IIf")
        Dim TreeNode138 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Switch")
        Dim TreeNode139 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Program Flow", New System.Windows.Forms.TreeNode() {TreeNode136, TreeNode137, TreeNode138})
        Dim TreeNode140 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Avg")
        Dim TreeNode141 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Count")
        Dim TreeNode142 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Max")
        Dim TreeNode143 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Min")
        Dim TreeNode144 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StDev")
        Dim TreeNode145 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StDevP")
        Dim TreeNode146 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sum")
        Dim TreeNode147 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Var")
        Dim TreeNode148 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("VarP")
        Dim TreeNode149 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("SQL Aggregate", New System.Windows.Forms.TreeNode() {TreeNode140, TreeNode141, TreeNode142, TreeNode143, TreeNode144, TreeNode145, TreeNode146, TreeNode147, TreeNode148})
        Dim TreeNode150 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Asc")
        Dim TreeNode151 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chr")
        Dim TreeNode152 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chr$")
        Dim TreeNode153 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Format")
        Dim TreeNode154 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Format$")
        Dim TreeNode155 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("GUIDFromString")
        Dim TreeNode156 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("InStr")
        Dim TreeNode157 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("InStrRev")
        Dim TreeNode158 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("LCase")
        Dim TreeNode159 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("LCase$")
        Dim TreeNode160 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Left")
        Dim TreeNode161 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Left$")
        Dim TreeNode162 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Len")
        Dim TreeNode163 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("LTrim")
        Dim TreeNode164 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("LTrim$")
        Dim TreeNode165 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mid")
        Dim TreeNode166 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mid$")
        Dim TreeNode167 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Replace")
        Dim TreeNode168 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Right")
        Dim TreeNode169 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Right$")
        Dim TreeNode170 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("RTrim")
        Dim TreeNode171 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("RTrim$")
        Dim TreeNode172 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Space")
        Dim TreeNode173 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Space$")
        Dim TreeNode174 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StrComp")
        Dim TreeNode175 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StrConv")
        Dim TreeNode176 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("String")
        Dim TreeNode177 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("String$")
        Dim TreeNode178 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StringFromGUID")
        Dim TreeNode179 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("StrReverse")
        Dim TreeNode180 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Trim")
        Dim TreeNode181 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Trim$")
        Dim TreeNode182 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("UCase")
        Dim TreeNode183 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("UCase$")
        Dim TreeNode184 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Text", New System.Windows.Forms.TreeNode() {TreeNode150, TreeNode151, TreeNode152, TreeNode153, TreeNode154, TreeNode155, TreeNode156, TreeNode157, TreeNode158, TreeNode159, TreeNode160, TreeNode161, TreeNode162, TreeNode163, TreeNode164, TreeNode165, TreeNode166, TreeNode167, TreeNode168, TreeNode169, TreeNode170, TreeNode171, TreeNode172, TreeNode173, TreeNode174, TreeNode175, TreeNode176, TreeNode177, TreeNode178, TreeNode179, TreeNode180, TreeNode181, TreeNode182, TreeNode183})
        Dim TreeNode185 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Functions", 1, 1, New System.Windows.Forms.TreeNode() {TreeNode4, TreeNode46, TreeNode52, TreeNode78, TreeNode90, TreeNode96, TreeNode110, TreeNode121, TreeNode135, TreeNode139, TreeNode149, TreeNode184})
        Me.CntxtMnu_TrView_dbObjects_DB = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.Cmnu_DB_Refresh = New System.Windows.Forms.ToolStripMenuItem
        Me.Cmnu_DB_Connect = New System.Windows.Forms.ToolStripMenuItem
        Me.ContextMnu_RText = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.Cmnu_Undo = New System.Windows.Forms.ToolStripMenuItem
        Me.Cmnu_Redo = New System.Windows.Forms.ToolStripMenuItem
        Me.ContextMnu_RText_Sep0 = New System.Windows.Forms.ToolStripSeparator
        Me.Cmnu_Cut = New System.Windows.Forms.ToolStripMenuItem
        Me.Cmnu_Copy = New System.Windows.Forms.ToolStripMenuItem
        Me.Cmnu_Paste = New System.Windows.Forms.ToolStripMenuItem
        Me.ContextMnu_RText_Sep1 = New System.Windows.Forms.ToolStripSeparator
        Me.Cmnu_SelectAll = New System.Windows.Forms.ToolStripMenuItem
        Me.ContextMnu_RText_Sep2 = New System.Windows.Forms.ToolStripSeparator
        Me.Cmnu_EditorOptions = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Main = New System.Windows.Forms.MenuStrip
        Me.mnu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_File_NewQuery = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_FileSep0 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_Connect = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_FileSep1 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_Open = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_SaveAs = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Save = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_FileSep2 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_View = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_ObjectsBrowser = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_ShowOutPutPanel = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Edit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Undo = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Redo = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_EditSep0 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_Cut = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Copy = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Paste = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_EditSep1 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_SelectAll = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Find = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Replace = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Format = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_WordWrap = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Font = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_EditorOptions = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Output = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_ClearOutPut = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Export2ExcelByHTML = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Export2ExcelByXML = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Export2ExcelByExcelApp = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Query = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Exec = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Query_Parameters = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_QuerySep0 = New System.Windows.Forms.ToolStripSeparator
        Me.mnu_Convert2Code = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_TutorialFeatures = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.MainStatusStrip = New System.Windows.Forms.StatusStrip
        Me.status_CurTask = New System.Windows.Forms.ToolStripStatusLabel
        Me.status_OutPutCount = New System.Windows.Forms.ToolStripStatusLabel
        Me.status_CurLine = New System.Windows.Forms.ToolStripStatusLabel
        Me.status_CurCol = New System.Windows.Forms.ToolStripStatusLabel
        Me.Status_Ins_Ovr = New System.Windows.Forms.ToolStripStatusLabel
        Me.status_Connection = New System.Windows.Forms.ToolStripStatusLabel
        Me.MainToolStrip = New System.Windows.Forms.ToolStrip
        Me.ToolBar_Connect = New System.Windows.Forms.ToolStripButton
        Me.ToolBar_Sep0 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolBar_Open = New System.Windows.Forms.ToolStripButton
        Me.ToolBar_Save = New System.Windows.Forms.ToolStripButton
        Me.ToolBar_Sep1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolBar_Cut = New System.Windows.Forms.ToolStripButton
        Me.ToolBar_Copy = New System.Windows.Forms.ToolStripButton
        Me.ToolBar_Paste = New System.Windows.Forms.ToolStripButton
        Me.ToolBar_Sep2 = New System.Windows.Forms.ToolStripSeparator
        Me.btn_Exec = New System.Windows.Forms.ToolStripButton
        Me.Split_Doc_And_Output = New System.Windows.Forms.SplitContainer
        Me.Rtext_Doc = New QueryEditor.ColoringWords.DevRichTextBox
        Me.Tabs_Output = New System.Windows.Forms.TabControl
        Me.TabPage_OutPutDGV = New System.Windows.Forms.TabPage
        Me.dgv_OutPut = New QueryEditor.DevDataGridView
        Me.TabPage_OutPutTxt = New System.Windows.Forms.TabPage
        Me.txt_OutPut = New System.Windows.Forms.TextBox
        Me.ToolTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.Split_ObjBrowser_And_Others = New System.Windows.Forms.SplitContainer
        Me.TrView_dbObjects = New QueryEditor.DevTreeView
        Me.CntxtMnu_TrView_dbObjects_Tblqry = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript = New System.Windows.Forms.ToolStripMenuItem
        Me.CntxtMnu_TrView_dbObjects_Tblqry_GenDrop = New System.Windows.Forms.ToolStripMenuItem
        Me.CntxtMnu_TrView_dbObjects_DB.SuspendLayout()
        Me.ContextMnu_RText.SuspendLayout()
        Me.mnu_Main.SuspendLayout()
        Me.MainStatusStrip.SuspendLayout()
        Me.MainToolStrip.SuspendLayout()
        Me.Split_Doc_And_Output.Panel1.SuspendLayout()
        Me.Split_Doc_And_Output.Panel2.SuspendLayout()
        Me.Split_Doc_And_Output.SuspendLayout()
        Me.Tabs_Output.SuspendLayout()
        Me.TabPage_OutPutDGV.SuspendLayout()
        CType(Me.dgv_OutPut, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_OutPutTxt.SuspendLayout()
        Me.Split_ObjBrowser_And_Others.Panel1.SuspendLayout()
        Me.Split_ObjBrowser_And_Others.Panel2.SuspendLayout()
        Me.Split_ObjBrowser_And_Others.SuspendLayout()
        Me.CntxtMnu_TrView_dbObjects_Tblqry.SuspendLayout()
        Me.SuspendLayout()
        '
        'CntxtMnu_TrView_dbObjects_DB
        '
        Me.CntxtMnu_TrView_dbObjects_DB.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Cmnu_DB_Refresh, Me.Cmnu_DB_Connect})
        Me.CntxtMnu_TrView_dbObjects_DB.Name = "CntxtMnu_TrView_dbObjects"
        Me.CntxtMnu_TrView_dbObjects_DB.Size = New System.Drawing.Size(115, 48)
        '
        'Cmnu_DB_Refresh
        '
        Me.Cmnu_DB_Refresh.Image = Global.QueryEditor.My.Resources.Resources.Refresh
        Me.Cmnu_DB_Refresh.Name = "Cmnu_DB_Refresh"
        Me.Cmnu_DB_Refresh.Size = New System.Drawing.Size(114, 22)
        Me.Cmnu_DB_Refresh.Text = "Refresh"
        '
        'Cmnu_DB_Connect
        '
        Me.Cmnu_DB_Connect.Name = "Cmnu_DB_Connect"
        Me.Cmnu_DB_Connect.Size = New System.Drawing.Size(114, 22)
        Me.Cmnu_DB_Connect.Text = "Connect"
        '
        'ContextMnu_RText
        '
        Me.ContextMnu_RText.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Cmnu_Undo, Me.Cmnu_Redo, Me.ContextMnu_RText_Sep0, Me.Cmnu_Cut, Me.Cmnu_Copy, Me.Cmnu_Paste, Me.ContextMnu_RText_Sep1, Me.Cmnu_SelectAll, Me.ContextMnu_RText_Sep2, Me.Cmnu_EditorOptions})
        Me.ContextMnu_RText.Name = "ContextMnu_RText"
        Me.ContextMnu_RText.Size = New System.Drawing.Size(157, 176)
        Me.ContextMnu_RText.Text = "ContextMnu_RText"
        '
        'Cmnu_Undo
        '
        Me.Cmnu_Undo.Name = "Cmnu_Undo"
        Me.Cmnu_Undo.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.Cmnu_Undo.Size = New System.Drawing.Size(156, 22)
        Me.Cmnu_Undo.Text = "Undo"
        '
        'Cmnu_Redo
        '
        Me.Cmnu_Redo.Name = "Cmnu_Redo"
        Me.Cmnu_Redo.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.Cmnu_Redo.Size = New System.Drawing.Size(156, 22)
        Me.Cmnu_Redo.Text = "Redo"
        '
        'ContextMnu_RText_Sep0
        '
        Me.ContextMnu_RText_Sep0.Name = "ContextMnu_RText_Sep0"
        Me.ContextMnu_RText_Sep0.Size = New System.Drawing.Size(153, 6)
        '
        'Cmnu_Cut
        '
        Me.Cmnu_Cut.Name = "Cmnu_Cut"
        Me.Cmnu_Cut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.Cmnu_Cut.Size = New System.Drawing.Size(156, 22)
        Me.Cmnu_Cut.Text = "Cut"
        '
        'Cmnu_Copy
        '
        Me.Cmnu_Copy.Name = "Cmnu_Copy"
        Me.Cmnu_Copy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.Cmnu_Copy.Size = New System.Drawing.Size(156, 22)
        Me.Cmnu_Copy.Text = "Copy"
        '
        'Cmnu_Paste
        '
        Me.Cmnu_Paste.Name = "Cmnu_Paste"
        Me.Cmnu_Paste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.Cmnu_Paste.Size = New System.Drawing.Size(156, 22)
        Me.Cmnu_Paste.Text = "Paste"
        '
        'ContextMnu_RText_Sep1
        '
        Me.ContextMnu_RText_Sep1.Name = "ContextMnu_RText_Sep1"
        Me.ContextMnu_RText_Sep1.Size = New System.Drawing.Size(153, 6)
        '
        'Cmnu_SelectAll
        '
        Me.Cmnu_SelectAll.Name = "Cmnu_SelectAll"
        Me.Cmnu_SelectAll.ShortcutKeyDisplayString = ""
        Me.Cmnu_SelectAll.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.Cmnu_SelectAll.Size = New System.Drawing.Size(156, 22)
        Me.Cmnu_SelectAll.Text = "Select All"
        '
        'ContextMnu_RText_Sep2
        '
        Me.ContextMnu_RText_Sep2.Name = "ContextMnu_RText_Sep2"
        Me.ContextMnu_RText_Sep2.Size = New System.Drawing.Size(153, 6)
        '
        'Cmnu_EditorOptions
        '
        Me.Cmnu_EditorOptions.Name = "Cmnu_EditorOptions"
        Me.Cmnu_EditorOptions.Size = New System.Drawing.Size(156, 22)
        Me.Cmnu_EditorOptions.Text = "Editor Options"
        '
        'mnu_Main
        '
        Me.mnu_Main.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_File, Me.mnu_View, Me.mnu_Edit, Me.mnu_Format, Me.mnu_Output, Me.mnu_Query, Me.mnu_Help})
        Me.mnu_Main.Location = New System.Drawing.Point(0, 0)
        Me.mnu_Main.Name = "mnu_Main"
        Me.mnu_Main.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.mnu_Main.Size = New System.Drawing.Size(542, 24)
        Me.mnu_Main.TabIndex = 1
        Me.mnu_Main.Text = "MenuStrip1"
        '
        'mnu_File
        '
        Me.mnu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_File_NewQuery, Me.mnu_FileSep0, Me.mnu_Connect, Me.mnu_FileSep1, Me.mnu_Open, Me.mnu_SaveAs, Me.mnu_Save, Me.mnu_FileSep2, Me.mnu_Exit})
        Me.mnu_File.Name = "mnu_File"
        Me.mnu_File.Size = New System.Drawing.Size(35, 20)
        Me.mnu_File.Text = "&File"
        '
        'mnu_File_NewQuery
        '
        Me.mnu_File_NewQuery.Name = "mnu_File_NewQuery"
        Me.mnu_File_NewQuery.Size = New System.Drawing.Size(183, 22)
        Me.mnu_File_NewQuery.Text = "New Query"
        '
        'mnu_FileSep0
        '
        Me.mnu_FileSep0.Name = "mnu_FileSep0"
        Me.mnu_FileSep0.Size = New System.Drawing.Size(180, 6)
        '
        'mnu_Connect
        '
        Me.mnu_Connect.Name = "mnu_Connect"
        Me.mnu_Connect.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnu_Connect.Size = New System.Drawing.Size(183, 22)
        Me.mnu_Connect.Text = "Connect"
        '
        'mnu_FileSep1
        '
        Me.mnu_FileSep1.Name = "mnu_FileSep1"
        Me.mnu_FileSep1.Size = New System.Drawing.Size(180, 6)
        '
        'mnu_Open
        '
        Me.mnu_Open.Image = Global.QueryEditor.My.Resources.Resources.Open
        Me.mnu_Open.Name = "mnu_Open"
        Me.mnu_Open.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnu_Open.Size = New System.Drawing.Size(183, 22)
        Me.mnu_Open.Text = "Open"
        '
        'mnu_SaveAs
        '
        Me.mnu_SaveAs.Name = "mnu_SaveAs"
        Me.mnu_SaveAs.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnu_SaveAs.Size = New System.Drawing.Size(183, 22)
        Me.mnu_SaveAs.Text = "Save As"
        '
        'mnu_Save
        '
        Me.mnu_Save.Image = Global.QueryEditor.My.Resources.Resources.Save
        Me.mnu_Save.Name = "mnu_Save"
        Me.mnu_Save.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnu_Save.Size = New System.Drawing.Size(183, 22)
        Me.mnu_Save.Text = "Save"
        '
        'mnu_FileSep2
        '
        Me.mnu_FileSep2.Name = "mnu_FileSep2"
        Me.mnu_FileSep2.Size = New System.Drawing.Size(180, 6)
        '
        'mnu_Exit
        '
        Me.mnu_Exit.Name = "mnu_Exit"
        Me.mnu_Exit.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.mnu_Exit.Size = New System.Drawing.Size(183, 22)
        Me.mnu_Exit.Text = "Exit"
        '
        'mnu_View
        '
        Me.mnu_View.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_ObjectsBrowser, Me.mnu_ShowOutPutPanel})
        Me.mnu_View.Name = "mnu_View"
        Me.mnu_View.Size = New System.Drawing.Size(41, 20)
        Me.mnu_View.Text = "View"
        '
        'mnu_ObjectsBrowser
        '
        Me.mnu_ObjectsBrowser.Checked = True
        Me.mnu_ObjectsBrowser.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnu_ObjectsBrowser.Name = "mnu_ObjectsBrowser"
        Me.mnu_ObjectsBrowser.ShortcutKeys = System.Windows.Forms.Keys.F2
        Me.mnu_ObjectsBrowser.Size = New System.Drawing.Size(210, 22)
        Me.mnu_ObjectsBrowser.Text = "Objects Browser"
        '
        'mnu_ShowOutPutPanel
        '
        Me.mnu_ShowOutPutPanel.Checked = True
        Me.mnu_ShowOutPutPanel.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnu_ShowOutPutPanel.Name = "mnu_ShowOutPutPanel"
        Me.mnu_ShowOutPutPanel.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnu_ShowOutPutPanel.Size = New System.Drawing.Size(210, 22)
        Me.mnu_ShowOutPutPanel.Text = "Out put Panel"
        '
        'mnu_Edit
        '
        Me.mnu_Edit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_Undo, Me.mnu_Redo, Me.mnu_EditSep0, Me.mnu_Cut, Me.mnu_Copy, Me.mnu_Paste, Me.mnu_EditSep1, Me.mnu_SelectAll, Me.mnu_Find, Me.mnu_Replace})
        Me.mnu_Edit.Name = "mnu_Edit"
        Me.mnu_Edit.Size = New System.Drawing.Size(37, 20)
        Me.mnu_Edit.Text = "Edit"
        '
        'mnu_Undo
        '
        Me.mnu_Undo.Image = Global.QueryEditor.My.Resources.Resources.Undo
        Me.mnu_Undo.Name = "mnu_Undo"
        Me.mnu_Undo.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.mnu_Undo.Size = New System.Drawing.Size(156, 22)
        Me.mnu_Undo.Text = "Undo"
        '
        'mnu_Redo
        '
        Me.mnu_Redo.Image = Global.QueryEditor.My.Resources.Resources.Redo
        Me.mnu_Redo.Name = "mnu_Redo"
        Me.mnu_Redo.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.mnu_Redo.Size = New System.Drawing.Size(156, 22)
        Me.mnu_Redo.Text = "Redo"
        '
        'mnu_EditSep0
        '
        Me.mnu_EditSep0.Name = "mnu_EditSep0"
        Me.mnu_EditSep0.Size = New System.Drawing.Size(153, 6)
        '
        'mnu_Cut
        '
        Me.mnu_Cut.Image = Global.QueryEditor.My.Resources.Resources.Cut
        Me.mnu_Cut.Name = "mnu_Cut"
        Me.mnu_Cut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnu_Cut.Size = New System.Drawing.Size(156, 22)
        Me.mnu_Cut.Text = "Cut"
        '
        'mnu_Copy
        '
        Me.mnu_Copy.Image = Global.QueryEditor.My.Resources.Resources.Copy
        Me.mnu_Copy.Name = "mnu_Copy"
        Me.mnu_Copy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnu_Copy.Size = New System.Drawing.Size(156, 22)
        Me.mnu_Copy.Text = "Copy"
        '
        'mnu_Paste
        '
        Me.mnu_Paste.Image = Global.QueryEditor.My.Resources.Resources.Paste
        Me.mnu_Paste.Name = "mnu_Paste"
        Me.mnu_Paste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnu_Paste.Size = New System.Drawing.Size(156, 22)
        Me.mnu_Paste.Text = "Paste"
        '
        'mnu_EditSep1
        '
        Me.mnu_EditSep1.Name = "mnu_EditSep1"
        Me.mnu_EditSep1.Size = New System.Drawing.Size(153, 6)
        '
        'mnu_SelectAll
        '
        Me.mnu_SelectAll.Name = "mnu_SelectAll"
        Me.mnu_SelectAll.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.mnu_SelectAll.Size = New System.Drawing.Size(156, 22)
        Me.mnu_SelectAll.Text = "Select All"
        '
        'mnu_Find
        '
        Me.mnu_Find.Image = CType(resources.GetObject("mnu_Find.Image"), System.Drawing.Image)
        Me.mnu_Find.Name = "mnu_Find"
        Me.mnu_Find.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.mnu_Find.Size = New System.Drawing.Size(156, 22)
        Me.mnu_Find.Text = "Find"
        '
        'mnu_Replace
        '
        Me.mnu_Replace.Image = Global.QueryEditor.My.Resources.Resources.Replace1
        Me.mnu_Replace.Name = "mnu_Replace"
        Me.mnu_Replace.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.H), System.Windows.Forms.Keys)
        Me.mnu_Replace.Size = New System.Drawing.Size(156, 22)
        Me.mnu_Replace.Text = "Replace"
        '
        'mnu_Format
        '
        Me.mnu_Format.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_WordWrap, Me.mnu_Font, Me.mnu_EditorOptions})
        Me.mnu_Format.Name = "mnu_Format"
        Me.mnu_Format.Size = New System.Drawing.Size(53, 20)
        Me.mnu_Format.Text = "Format"
        '
        'mnu_WordWrap
        '
        Me.mnu_WordWrap.Checked = True
        Me.mnu_WordWrap.CheckOnClick = True
        Me.mnu_WordWrap.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnu_WordWrap.Name = "mnu_WordWrap"
        Me.mnu_WordWrap.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.mnu_WordWrap.Size = New System.Drawing.Size(171, 22)
        Me.mnu_WordWrap.Text = "Word Wrap"
        '
        'mnu_Font
        '
        Me.mnu_Font.Name = "mnu_Font"
        Me.mnu_Font.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.mnu_Font.Size = New System.Drawing.Size(171, 22)
        Me.mnu_Font.Text = "Font"
        '
        'mnu_EditorOptions
        '
        Me.mnu_EditorOptions.Name = "mnu_EditorOptions"
        Me.mnu_EditorOptions.Size = New System.Drawing.Size(171, 22)
        Me.mnu_EditorOptions.Text = "Editor Options"
        '
        'mnu_Output
        '
        Me.mnu_Output.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_ClearOutPut, Me.mnu_Export2ExcelByHTML, Me.mnu_Export2ExcelByXML, Me.mnu_Export2ExcelByExcelApp})
        Me.mnu_Output.Name = "mnu_Output"
        Me.mnu_Output.Size = New System.Drawing.Size(53, 20)
        Me.mnu_Output.Text = "Output"
        '
        'mnu_ClearOutPut
        '
        Me.mnu_ClearOutPut.Name = "mnu_ClearOutPut"
        Me.mnu_ClearOutPut.Size = New System.Drawing.Size(212, 22)
        Me.mnu_ClearOutPut.Text = "Clear Output"
        '
        'mnu_Export2ExcelByHTML
        '
        Me.mnu_Export2ExcelByHTML.Name = "mnu_Export2ExcelByHTML"
        Me.mnu_Export2ExcelByHTML.Size = New System.Drawing.Size(212, 22)
        Me.mnu_Export2ExcelByHTML.Text = "Export to Excel By HTML"
        '
        'mnu_Export2ExcelByXML
        '
        Me.mnu_Export2ExcelByXML.Name = "mnu_Export2ExcelByXML"
        Me.mnu_Export2ExcelByXML.Size = New System.Drawing.Size(212, 22)
        Me.mnu_Export2ExcelByXML.Text = "Export to Excel By XML"
        '
        'mnu_Export2ExcelByExcelApp
        '
        Me.mnu_Export2ExcelByExcelApp.Name = "mnu_Export2ExcelByExcelApp"
        Me.mnu_Export2ExcelByExcelApp.Size = New System.Drawing.Size(212, 22)
        Me.mnu_Export2ExcelByExcelApp.Text = "Export to Excel By Excel App"
        '
        'mnu_Query
        '
        Me.mnu_Query.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_Exec, Me.mnu_Query_Parameters, Me.mnu_QuerySep0, Me.mnu_Convert2Code})
        Me.mnu_Query.Name = "mnu_Query"
        Me.mnu_Query.Size = New System.Drawing.Size(49, 20)
        Me.mnu_Query.Text = "&Query"
        '
        'mnu_Exec
        '
        Me.mnu_Exec.Image = Global.QueryEditor.My.Resources.Resources.Exec
        Me.mnu_Exec.Name = "mnu_Exec"
        Me.mnu_Exec.ShortcutKeys = System.Windows.Forms.Keys.F5
        Me.mnu_Exec.Size = New System.Drawing.Size(224, 22)
        Me.mnu_Exec.Text = "Execute"
        '
        'mnu_Query_Parameters
        '
        Me.mnu_Query_Parameters.Name = "mnu_Query_Parameters"
        Me.mnu_Query_Parameters.ShortcutKeys = System.Windows.Forms.Keys.F6
        Me.mnu_Query_Parameters.Size = New System.Drawing.Size(224, 22)
        Me.mnu_Query_Parameters.Text = "Parameters"
        '
        'mnu_QuerySep0
        '
        Me.mnu_QuerySep0.Name = "mnu_QuerySep0"
        Me.mnu_QuerySep0.Size = New System.Drawing.Size(221, 6)
        '
        'mnu_Convert2Code
        '
        Me.mnu_Convert2Code.Name = "mnu_Convert2Code"
        Me.mnu_Convert2Code.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnu_Convert2Code.Size = New System.Drawing.Size(224, 22)
        Me.mnu_Convert2Code.Text = "Convert To Code"
        '
        'mnu_Help
        '
        Me.mnu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_TutorialFeatures, Me.mnu_About})
        Me.mnu_Help.Name = "mnu_Help"
        Me.mnu_Help.Size = New System.Drawing.Size(40, 20)
        Me.mnu_Help.Text = "Help"
        '
        'mnu_TutorialFeatures
        '
        Me.mnu_TutorialFeatures.Name = "mnu_TutorialFeatures"
        Me.mnu_TutorialFeatures.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.mnu_TutorialFeatures.Size = New System.Drawing.Size(185, 22)
        Me.mnu_TutorialFeatures.Text = "Tutorial && Features"
        '
        'mnu_About
        '
        Me.mnu_About.Name = "mnu_About"
        Me.mnu_About.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.mnu_About.Size = New System.Drawing.Size(185, 22)
        Me.mnu_About.Text = "About"
        '
        'MainStatusStrip
        '
        Me.MainStatusStrip.GripMargin = New System.Windows.Forms.Padding(1)
        Me.MainStatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.status_CurTask, Me.status_OutPutCount, Me.status_CurLine, Me.status_CurCol, Me.Status_Ins_Ovr, Me.status_Connection})
        Me.MainStatusStrip.Location = New System.Drawing.Point(0, 351)
        Me.MainStatusStrip.Name = "MainStatusStrip"
        Me.MainStatusStrip.ShowItemToolTips = True
        Me.MainStatusStrip.Size = New System.Drawing.Size(542, 22)
        Me.MainStatusStrip.TabIndex = 2
        '
        'status_CurTask
        '
        Me.status_CurTask.AutoSize = False
        Me.status_CurTask.AutoToolTip = True
        Me.status_CurTask.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.status_CurTask.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.status_CurTask.Margin = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.status_CurTask.Name = "status_CurTask"
        Me.status_CurTask.Size = New System.Drawing.Size(150, 19)
        Me.status_CurTask.Text = "Ready"
        Me.status_CurTask.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'status_OutPutCount
        '
        Me.status_OutPutCount.AutoSize = False
        Me.status_OutPutCount.AutoToolTip = True
        Me.status_OutPutCount.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.status_OutPutCount.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.status_OutPutCount.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.status_OutPutCount.Margin = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.status_OutPutCount.Name = "status_OutPutCount"
        Me.status_OutPutCount.Size = New System.Drawing.Size(100, 19)
        Me.status_OutPutCount.Text = "0 Row(s)"
        Me.status_OutPutCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'status_CurLine
        '
        Me.status_CurLine.AutoSize = False
        Me.status_CurLine.AutoToolTip = True
        Me.status_CurLine.BorderSides = CType(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.status_CurLine.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.status_CurLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.status_CurLine.Margin = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.status_CurLine.Name = "status_CurLine"
        Me.status_CurLine.Size = New System.Drawing.Size(60, 19)
        Me.status_CurLine.Text = "Ln 0"
        Me.status_CurLine.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'status_CurCol
        '
        Me.status_CurCol.AutoSize = False
        Me.status_CurCol.AutoToolTip = True
        Me.status_CurCol.BorderSides = CType(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.status_CurCol.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.status_CurCol.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.status_CurCol.Margin = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.status_CurCol.Name = "status_CurCol"
        Me.status_CurCol.Size = New System.Drawing.Size(60, 19)
        Me.status_CurCol.Text = "Col 0"
        Me.status_CurCol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Status_Ins_Ovr
        '
        Me.Status_Ins_Ovr.AutoSize = False
        Me.Status_Ins_Ovr.AutoToolTip = True
        Me.Status_Ins_Ovr.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.Status_Ins_Ovr.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.Status_Ins_Ovr.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Status_Ins_Ovr.Margin = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.Status_Ins_Ovr.Name = "Status_Ins_Ovr"
        Me.Status_Ins_Ovr.Size = New System.Drawing.Size(30, 19)
        Me.Status_Ins_Ovr.Text = "INS"
        Me.Status_Ins_Ovr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'status_Connection
        '
        Me.status_Connection.AutoSize = False
        Me.status_Connection.AutoToolTip = True
        Me.status_Connection.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.status_Connection.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.status_Connection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.status_Connection.Margin = New System.Windows.Forms.Padding(0, 3, 0, 0)
        Me.status_Connection.Name = "status_Connection"
        Me.status_Connection.Size = New System.Drawing.Size(127, 19)
        Me.status_Connection.Spring = True
        Me.status_Connection.Text = "DB : "
        Me.status_Connection.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'MainToolStrip
        '
        Me.MainToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolBar_Connect, Me.ToolBar_Sep0, Me.ToolBar_Open, Me.ToolBar_Save, Me.ToolBar_Sep1, Me.ToolBar_Cut, Me.ToolBar_Copy, Me.ToolBar_Paste, Me.ToolBar_Sep2, Me.btn_Exec})
        Me.MainToolStrip.Location = New System.Drawing.Point(0, 24)
        Me.MainToolStrip.Name = "MainToolStrip"
        Me.MainToolStrip.Size = New System.Drawing.Size(542, 25)
        Me.MainToolStrip.TabIndex = 3
        Me.MainToolStrip.Text = "MainToolStrip"
        '
        'ToolBar_Connect
        '
        Me.ToolBar_Connect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolBar_Connect.Image = CType(resources.GetObject("ToolBar_Connect.Image"), System.Drawing.Image)
        Me.ToolBar_Connect.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolBar_Connect.Name = "ToolBar_Connect"
        Me.ToolBar_Connect.Size = New System.Drawing.Size(23, 22)
        Me.ToolBar_Connect.Text = "Connect to a new DataBase"
        '
        'ToolBar_Sep0
        '
        Me.ToolBar_Sep0.Name = "ToolBar_Sep0"
        Me.ToolBar_Sep0.Size = New System.Drawing.Size(6, 25)
        '
        'ToolBar_Open
        '
        Me.ToolBar_Open.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolBar_Open.Image = Global.QueryEditor.My.Resources.Resources.Open
        Me.ToolBar_Open.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolBar_Open.Name = "ToolBar_Open"
        Me.ToolBar_Open.Size = New System.Drawing.Size(23, 22)
        Me.ToolBar_Open.Text = "Open an existing SQL Statment file "
        '
        'ToolBar_Save
        '
        Me.ToolBar_Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolBar_Save.Image = Global.QueryEditor.My.Resources.Resources.Save
        Me.ToolBar_Save.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolBar_Save.Name = "ToolBar_Save"
        Me.ToolBar_Save.Size = New System.Drawing.Size(23, 22)
        Me.ToolBar_Save.Text = "Save current SQL Statement file"
        '
        'ToolBar_Sep1
        '
        Me.ToolBar_Sep1.Name = "ToolBar_Sep1"
        Me.ToolBar_Sep1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolBar_Cut
        '
        Me.ToolBar_Cut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolBar_Cut.Image = Global.QueryEditor.My.Resources.Resources.Cut
        Me.ToolBar_Cut.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolBar_Cut.Name = "ToolBar_Cut"
        Me.ToolBar_Cut.Size = New System.Drawing.Size(23, 22)
        Me.ToolBar_Cut.Text = "Cut"
        '
        'ToolBar_Copy
        '
        Me.ToolBar_Copy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolBar_Copy.Image = Global.QueryEditor.My.Resources.Resources.Copy
        Me.ToolBar_Copy.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolBar_Copy.Name = "ToolBar_Copy"
        Me.ToolBar_Copy.Size = New System.Drawing.Size(23, 22)
        Me.ToolBar_Copy.Text = "Copy"
        '
        'ToolBar_Paste
        '
        Me.ToolBar_Paste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolBar_Paste.Image = Global.QueryEditor.My.Resources.Resources.Paste
        Me.ToolBar_Paste.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolBar_Paste.Name = "ToolBar_Paste"
        Me.ToolBar_Paste.Size = New System.Drawing.Size(23, 22)
        Me.ToolBar_Paste.Text = "Paste"
        '
        'ToolBar_Sep2
        '
        Me.ToolBar_Sep2.Name = "ToolBar_Sep2"
        Me.ToolBar_Sep2.Size = New System.Drawing.Size(6, 25)
        '
        'btn_Exec
        '
        Me.btn_Exec.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_Exec.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Exec.ForeColor = System.Drawing.Color.Red
        Me.btn_Exec.Image = Global.QueryEditor.My.Resources.Resources.Exec
        Me.btn_Exec.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_Exec.Name = "btn_Exec"
        Me.btn_Exec.Size = New System.Drawing.Size(23, 22)
        Me.btn_Exec.Text = "Execute"
        Me.btn_Exec.ToolTipText = "Execute"
        '
        'Split_Doc_And_Output
        '
        Me.Split_Doc_And_Output.BackColor = System.Drawing.SystemColors.Control
        Me.Split_Doc_And_Output.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Split_Doc_And_Output.Location = New System.Drawing.Point(0, 0)
        Me.Split_Doc_And_Output.Name = "Split_Doc_And_Output"
        Me.Split_Doc_And_Output.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'Split_Doc_And_Output.Panel1
        '
        Me.Split_Doc_And_Output.Panel1.Controls.Add(Me.Rtext_Doc)
        Me.Split_Doc_And_Output.Panel1MinSize = 160
        '
        'Split_Doc_And_Output.Panel2
        '
        Me.Split_Doc_And_Output.Panel2.Controls.Add(Me.Tabs_Output)
        Me.Split_Doc_And_Output.Panel2MinSize = 100
        Me.Split_Doc_And_Output.Size = New System.Drawing.Size(430, 298)
        Me.Split_Doc_And_Output.SplitterDistance = 160
        Me.Split_Doc_And_Output.TabIndex = 0
        '
        'Rtext_Doc
        '
        Me.Rtext_Doc.AcceptsTab = True
        Me.Rtext_Doc.AutoWordSelection = True
        Me.Rtext_Doc.CausesValidation = False
        Me.Rtext_Doc.ContextMenuStrip = Me.ContextMnu_RText
        Me.Rtext_Doc.DetectUrls = False
        Me.Rtext_Doc.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Rtext_Doc.EnableAutoDragDrop = True
        Me.Rtext_Doc.FileName = Nothing
        Me.Rtext_Doc.Font = New System.Drawing.Font("Tahoma", 15.0!)
        Me.Rtext_Doc.ForeColor = System.Drawing.Color.Black
        Me.Rtext_Doc.HideSelection = False
        Me.Rtext_Doc.Location = New System.Drawing.Point(0, 0)
        Me.Rtext_Doc.Name = "Rtext_Doc"
        Me.Rtext_Doc.Size = New System.Drawing.Size(430, 160)
        Me.Rtext_Doc.TabIndex = 0
        Me.Rtext_Doc.Text = ""
        '
        'Tabs_Output
        '
        Me.Tabs_Output.AllowDrop = True
        Me.Tabs_Output.Controls.Add(Me.TabPage_OutPutDGV)
        Me.Tabs_Output.Controls.Add(Me.TabPage_OutPutTxt)
        Me.Tabs_Output.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Tabs_Output.Location = New System.Drawing.Point(0, 0)
        Me.Tabs_Output.Name = "Tabs_Output"
        Me.Tabs_Output.SelectedIndex = 0
        Me.Tabs_Output.Size = New System.Drawing.Size(430, 134)
        Me.Tabs_Output.TabIndex = 0
        '
        'TabPage_OutPutDGV
        '
        Me.TabPage_OutPutDGV.Controls.Add(Me.dgv_OutPut)
        Me.TabPage_OutPutDGV.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_OutPutDGV.Name = "TabPage_OutPutDGV"
        Me.TabPage_OutPutDGV.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_OutPutDGV.Size = New System.Drawing.Size(422, 108)
        Me.TabPage_OutPutDGV.TabIndex = 0
        Me.TabPage_OutPutDGV.Text = "Grid"
        Me.TabPage_OutPutDGV.UseVisualStyleBackColor = True
        '
        'dgv_OutPut
        '
        Me.dgv_OutPut.AllowUserToAddRows = False
        Me.dgv_OutPut.AllowUserToDeleteRows = False
        Me.dgv_OutPut.AllowUserToOrderColumns = True
        Me.dgv_OutPut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_OutPut.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_OutPut.IndexOnRowHeader = True
        Me.dgv_OutPut.Location = New System.Drawing.Point(3, 3)
        Me.dgv_OutPut.Name = "dgv_OutPut"
        Me.dgv_OutPut.ReadOnly = True
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.dgv_OutPut.RowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv_OutPut.Size = New System.Drawing.Size(416, 102)
        Me.dgv_OutPut.TabIndex = 0
        '
        'TabPage_OutPutTxt
        '
        Me.TabPage_OutPutTxt.Controls.Add(Me.txt_OutPut)
        Me.TabPage_OutPutTxt.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_OutPutTxt.Name = "TabPage_OutPutTxt"
        Me.TabPage_OutPutTxt.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_OutPutTxt.Size = New System.Drawing.Size(422, 108)
        Me.TabPage_OutPutTxt.TabIndex = 1
        Me.TabPage_OutPutTxt.Text = "Message"
        Me.TabPage_OutPutTxt.UseVisualStyleBackColor = True
        '
        'txt_OutPut
        '
        Me.txt_OutPut.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_OutPut.Location = New System.Drawing.Point(3, 3)
        Me.txt_OutPut.Multiline = True
        Me.txt_OutPut.Name = "txt_OutPut"
        Me.txt_OutPut.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txt_OutPut.Size = New System.Drawing.Size(416, 102)
        Me.txt_OutPut.TabIndex = 0
        Me.txt_OutPut.WordWrap = False
        '
        'Split_ObjBrowser_And_Others
        '
        Me.Split_ObjBrowser_And_Others.BackColor = System.Drawing.SystemColors.Control
        Me.Split_ObjBrowser_And_Others.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Split_ObjBrowser_And_Others.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Split_ObjBrowser_And_Others.Location = New System.Drawing.Point(0, 49)
        Me.Split_ObjBrowser_And_Others.Name = "Split_ObjBrowser_And_Others"
        '
        'Split_ObjBrowser_And_Others.Panel1
        '
        Me.Split_ObjBrowser_And_Others.Panel1.Controls.Add(Me.TrView_dbObjects)
        Me.Split_ObjBrowser_And_Others.Panel1MinSize = 80
        '
        'Split_ObjBrowser_And_Others.Panel2
        '
        Me.Split_ObjBrowser_And_Others.Panel2.Controls.Add(Me.Split_Doc_And_Output)
        Me.Split_ObjBrowser_And_Others.Panel2MinSize = 100
        Me.Split_ObjBrowser_And_Others.Size = New System.Drawing.Size(542, 302)
        Me.Split_ObjBrowser_And_Others.SplitterDistance = 104
        Me.Split_ObjBrowser_And_Others.TabIndex = 5
        '
        'TrView_dbObjects
        '
        Me.TrView_dbObjects.AllowDrop = True
        Me.TrView_dbObjects.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TrView_dbObjects.ForeColor = System.Drawing.Color.Black
        Me.TrView_dbObjects.HideSelection = False
        Me.TrView_dbObjects.Location = New System.Drawing.Point(0, 0)
        Me.TrView_dbObjects.Name = "TrView_dbObjects"
        TreeNode1.ContextMenuStrip = Me.CntxtMnu_TrView_dbObjects_DB
        TreeNode1.ImageIndex = 0
        TreeNode1.Name = "node_DB"
        TreeNode1.SelectedImageIndex = 0
        TreeNode1.Text = "No DataBase"
        TreeNode2.Name = "Node14"
        TreeNode2.Text = "LBound"
        TreeNode3.Name = "Node15"
        TreeNode3.Text = "UBound"
        TreeNode4.Name = "Node3"
        TreeNode4.Text = "Array"
        TreeNode4.ToolTipText = "Array"
        TreeNode5.Name = "Node16"
        TreeNode5.Text = "Asc"
        TreeNode6.Name = "Node17"
        TreeNode6.Text = "CBool"
        TreeNode7.Name = "Node18"
        TreeNode7.Text = "CByte"
        TreeNode8.Name = "Node19"
        TreeNode8.Text = "CCur"
        TreeNode9.Name = "Node20"
        TreeNode9.Text = "CDate"
        TreeNode10.Name = "Node21"
        TreeNode10.Text = "CDbl"
        TreeNode11.Name = "Node22"
        TreeNode11.Text = "CDec"
        TreeNode12.Name = "Node23"
        TreeNode12.Text = "Chr"
        TreeNode13.Name = "Node24"
        TreeNode13.Text = "Chr$"
        TreeNode14.Name = "Node25"
        TreeNode14.Text = "CInt"
        TreeNode15.Name = "Node26"
        TreeNode15.Text = "Clng"
        TreeNode16.Name = "Node27"
        TreeNode16.Text = "CSng"
        TreeNode17.Name = "Node28"
        TreeNode17.Text = "CStr"
        TreeNode18.Name = "Node29"
        TreeNode18.Text = "CVar"
        TreeNode19.Name = "Node30"
        TreeNode19.Text = "CVDate"
        TreeNode20.Name = "Node31"
        TreeNode20.Text = "DateSerial"
        TreeNode21.Name = "Node32"
        TreeNode21.Text = "DateValue"
        TreeNode22.Name = "Node33"
        TreeNode22.Text = "Day"
        TreeNode23.Name = "Node34"
        TreeNode23.Text = "FormatCurrency"
        TreeNode24.Name = "Node35"
        TreeNode24.Text = "FormatDateTime"
        TreeNode25.Name = "Node36"
        TreeNode25.Text = "FormatNumber"
        TreeNode26.Name = "Node37"
        TreeNode26.Text = "FormatPercent"
        TreeNode27.Name = "Node38"
        TreeNode27.Text = "GUIDFromString"
        TreeNode28.Name = "Node39"
        TreeNode28.Text = "Hex"
        TreeNode29.Name = "Node40"
        TreeNode29.Text = " Hex$"
        TreeNode30.Name = "Node41"
        TreeNode30.Text = "Hour"
        TreeNode31.Name = "Node42"
        TreeNode31.Text = "Minute"
        TreeNode32.Name = "Node43"
        TreeNode32.Text = "Month"
        TreeNode33.Name = "Node44"
        TreeNode33.Text = "Nz"
        TreeNode34.Name = "Node45"
        TreeNode34.Text = "Oct"
        TreeNode35.Name = "Node46"
        TreeNode35.Text = "Oct$"
        TreeNode36.Name = "Node47"
        TreeNode36.Text = "Second"
        TreeNode37.Name = "Node48"
        TreeNode37.Text = "Str"
        TreeNode38.Name = "Node49"
        TreeNode38.Text = "Str$"
        TreeNode39.Name = "Node50"
        TreeNode39.Text = "StrConv"
        TreeNode40.Name = "Node51"
        TreeNode40.Text = "StringFromGUID"
        TreeNode41.Name = "Node52"
        TreeNode41.Text = "TimeSerial"
        TreeNode42.Name = "Node53"
        TreeNode42.Text = "TimeValue"
        TreeNode43.Name = "Node54"
        TreeNode43.Text = "Val"
        TreeNode44.Name = "Node55"
        TreeNode44.Text = "Weekday"
        TreeNode45.Name = "Node56"
        TreeNode45.Text = "Year"
        TreeNode46.Name = "Node4"
        TreeNode46.Text = "Conversion"
        TreeNode46.ToolTipText = "Conversion"
        TreeNode47.Name = "Node0"
        TreeNode47.Text = "CurrentUser"
        TreeNode48.Name = "Node1"
        TreeNode48.Text = "Eval"
        TreeNode49.Name = "Node2"
        TreeNode49.Text = "HyperlinkPart"
        TreeNode50.Name = "Node3"
        TreeNode50.Text = "IMEStatus"
        TreeNode51.Name = "Node4"
        TreeNode51.Text = "Partition"
        TreeNode52.Name = "Node5"
        TreeNode52.Text = "DataBase"
        TreeNode52.ToolTipText = "DataBase"
        TreeNode53.Name = "Node5"
        TreeNode53.Text = "CDate"
        TreeNode54.Name = "Node6"
        TreeNode54.Text = "CVDate"
        TreeNode55.Name = "Node7"
        TreeNode55.Text = "Date"
        TreeNode56.Name = "Node8"
        TreeNode56.Text = "Date$"
        TreeNode57.Name = "Node9"
        TreeNode57.Text = "DateAdd"
        TreeNode58.Name = "Node10"
        TreeNode58.Text = "DateDiff"
        TreeNode59.Name = "Node11"
        TreeNode59.Text = "DatePart"
        TreeNode60.Name = "Node12"
        TreeNode60.Text = "DateSerial"
        TreeNode61.Name = "Node13"
        TreeNode61.Text = "DateValue"
        TreeNode62.Name = "Node14"
        TreeNode62.Text = "Day"
        TreeNode63.Name = "Node16"
        TreeNode63.Text = "Hour"
        TreeNode64.Name = "Node17"
        TreeNode64.Text = "IsDate"
        TreeNode65.Name = "Node18"
        TreeNode65.Text = "Minute"
        TreeNode66.Name = "Node19"
        TreeNode66.Text = "Month"
        TreeNode67.Name = "Node20"
        TreeNode67.Text = "MonthName"
        TreeNode68.Name = "Node21"
        TreeNode68.Text = "Now"
        TreeNode69.Name = "Node22"
        TreeNode69.Text = "Second"
        TreeNode70.Name = "Node23"
        TreeNode70.Text = "Time"
        TreeNode71.Name = "Node24"
        TreeNode71.Text = "Time$"
        TreeNode72.Name = "Node25"
        TreeNode72.Text = "Timer"
        TreeNode73.Name = "Node26"
        TreeNode73.Text = "TimeSerial"
        TreeNode74.Name = "Node27"
        TreeNode74.Text = "TimeValue"
        TreeNode75.Name = "Node28"
        TreeNode75.Text = "Weekday"
        TreeNode76.Name = "Node29"
        TreeNode76.Text = "WeekdayName"
        TreeNode77.Name = "Node30"
        TreeNode77.Text = "Year"
        TreeNode78.Name = "Node2"
        TreeNode78.Text = "Date/Time"
        TreeNode78.ToolTipText = "Date/Time"
        TreeNode79.Name = "Node31"
        TreeNode79.Text = "DAvg"
        TreeNode80.Name = "Node32"
        TreeNode80.Text = "DCount"
        TreeNode81.Name = "Node33"
        TreeNode81.Text = "DFirst"
        TreeNode82.Name = "Node34"
        TreeNode82.Text = "DLast"
        TreeNode83.Name = "Node35"
        TreeNode83.Text = "DLookup"
        TreeNode84.Name = "Node36"
        TreeNode84.Text = "DMax"
        TreeNode85.Name = "Node37"
        TreeNode85.Text = "DMin"
        TreeNode86.Name = "Node39"
        TreeNode86.Text = "DStDev"
        TreeNode87.Name = "Node40"
        TreeNode87.Text = "DSum"
        TreeNode88.Name = "Node41"
        TreeNode88.Text = "DVar"
        TreeNode89.Name = "Node42"
        TreeNode89.Text = "DVarP"
        TreeNode90.Name = "Node6"
        TreeNode90.Text = "Domain Aggregatte"
        TreeNode90.ToolTipText = "Domain Aggregatte"
        TreeNode91.Name = "Node0"
        TreeNode91.Text = "CVErr"
        TreeNode92.Name = "Node1"
        TreeNode92.Text = "Err"
        TreeNode93.Name = "Node2"
        TreeNode93.Text = "Error"
        TreeNode94.Name = "Node3"
        TreeNode94.Text = "Error$"
        TreeNode95.Name = "Node4"
        TreeNode95.Text = "IsError"
        TreeNode96.Name = "Node7"
        TreeNode96.Text = "Error Handling"
        TreeNode96.ToolTipText = "Error Handling"
        TreeNode97.Name = "Node5"
        TreeNode97.Text = "DDB"
        TreeNode98.Name = "Node7"
        TreeNode98.Text = "FV"
        TreeNode99.Name = "Node8"
        TreeNode99.Text = "IPmt"
        TreeNode100.Name = "Node9"
        TreeNode100.Text = "IRR"
        TreeNode101.Name = "Node10"
        TreeNode101.Text = "MIRR"
        TreeNode102.Name = "Node11"
        TreeNode102.Text = "NPer"
        TreeNode103.Name = "Node12"
        TreeNode103.Text = "NPV"
        TreeNode104.Name = "Node13"
        TreeNode104.Text = "Pmt"
        TreeNode105.Name = "Node14"
        TreeNode105.Text = "PPmt"
        TreeNode106.Name = "Node15"
        TreeNode106.Text = "PV"
        TreeNode107.Name = "Node16"
        TreeNode107.Text = "Rate"
        TreeNode108.Name = "Node17"
        TreeNode108.Text = "SLN"
        TreeNode109.Name = "Node18"
        TreeNode109.Text = "SYD"
        TreeNode110.Name = "Node8"
        TreeNode110.Text = "Financial"
        TreeNode110.ToolTipText = "Financial"
        TreeNode111.Name = "Node19"
        TreeNode111.Text = "IsArray"
        TreeNode112.Name = "Node20"
        TreeNode112.Text = "IsDate"
        TreeNode113.Name = "Node21"
        TreeNode113.Text = "IsEmpty"
        TreeNode114.Name = "Node22"
        TreeNode114.Text = "IsError"
        TreeNode115.Name = "Node23"
        TreeNode115.Text = "IsMissing"
        TreeNode116.Name = "IsNull"
        TreeNode116.Text = "IsNull"
        TreeNode117.Name = "Node25"
        TreeNode117.Text = "IsNumeric"
        TreeNode118.Name = "Node26"
        TreeNode118.Text = "IsObject"
        TreeNode119.Name = "Node27"
        TreeNode119.Text = "TypeName"
        TreeNode120.Name = "Node28"
        TreeNode120.Text = "VarType"
        TreeNode121.Name = "Node9"
        TreeNode121.Text = "Inspection"
        TreeNode121.ToolTipText = "Inspection"
        TreeNode122.Name = "Node29"
        TreeNode122.Text = "Abs"
        TreeNode123.Name = "Node30"
        TreeNode123.Text = "Atn"
        TreeNode124.Name = "Node31"
        TreeNode124.Text = "Cos"
        TreeNode125.Name = "Node32"
        TreeNode125.Text = "Exp"
        TreeNode126.Name = "Node33"
        TreeNode126.Text = "Fix"
        TreeNode127.Name = "Node34"
        TreeNode127.Text = "Int"
        TreeNode128.Name = "Node35"
        TreeNode128.Text = "Log"
        TreeNode129.Name = "Node36"
        TreeNode129.Text = "Rnd"
        TreeNode130.Name = "Node37"
        TreeNode130.Text = "Round"
        TreeNode131.Name = "Node38"
        TreeNode131.Text = "Sgn"
        TreeNode132.Name = "Node39"
        TreeNode132.Text = "Sin"
        TreeNode133.Name = "Node40"
        TreeNode133.Text = "Sqr"
        TreeNode134.Name = "Node41"
        TreeNode134.Text = "Tan"
        TreeNode135.Name = "Node10"
        TreeNode135.Text = "Math"
        TreeNode135.ToolTipText = "Math"
        TreeNode136.Name = "Node42"
        TreeNode136.Text = "Choose"
        TreeNode137.Name = "Node43"
        TreeNode137.Text = "IIf"
        TreeNode138.Name = "Node44"
        TreeNode138.Text = "Switch"
        TreeNode139.Name = "Node11"
        TreeNode139.Text = "Program Flow"
        TreeNode139.ToolTipText = "Program Flow"
        TreeNode140.Name = "Node45"
        TreeNode140.Text = "Avg"
        TreeNode141.Name = "Node46"
        TreeNode141.Text = "Count"
        TreeNode142.Name = "Node47"
        TreeNode142.Text = "Max"
        TreeNode143.Name = "Node48"
        TreeNode143.Text = "Min"
        TreeNode144.Name = "Node49"
        TreeNode144.Text = "StDev"
        TreeNode145.Name = "Node50"
        TreeNode145.Text = "StDevP"
        TreeNode146.Name = "Node51"
        TreeNode146.Text = "Sum"
        TreeNode147.Name = "Node52"
        TreeNode147.Text = "Var"
        TreeNode148.Name = "Node53"
        TreeNode148.Text = "VarP"
        TreeNode149.Name = "Node12"
        TreeNode149.Text = "SQL Aggregate"
        TreeNode149.ToolTipText = "SQL Aggregate"
        TreeNode150.Name = "Node54"
        TreeNode150.Text = "Asc"
        TreeNode151.Name = "Node55"
        TreeNode151.Text = "Chr"
        TreeNode152.Name = "Node56"
        TreeNode152.Text = "Chr$"
        TreeNode153.Name = "Node57"
        TreeNode153.Text = "Format"
        TreeNode154.Name = "Node58"
        TreeNode154.Text = "Format$"
        TreeNode155.Name = "Node59"
        TreeNode155.Text = "GUIDFromString"
        TreeNode156.Name = "Node60"
        TreeNode156.Text = "InStr"
        TreeNode157.Name = "Node61"
        TreeNode157.Text = "InStrRev"
        TreeNode158.Name = "Node62"
        TreeNode158.Text = "LCase"
        TreeNode159.Name = "Node63"
        TreeNode159.Text = "LCase$"
        TreeNode160.Name = "Node64"
        TreeNode160.Text = "Left"
        TreeNode161.Name = "Node65"
        TreeNode161.Text = "Left$"
        TreeNode162.Name = "Node66"
        TreeNode162.Text = "Len"
        TreeNode163.Name = "Node67"
        TreeNode163.Text = "LTrim"
        TreeNode164.Name = "Node68"
        TreeNode164.Text = "LTrim$"
        TreeNode165.Name = "Node69"
        TreeNode165.Text = "Mid"
        TreeNode166.Name = "Node70"
        TreeNode166.Text = "Mid$"
        TreeNode167.Name = "Node71"
        TreeNode167.Text = "Replace"
        TreeNode168.Name = "Node72"
        TreeNode168.Text = "Right"
        TreeNode169.Name = "Node74"
        TreeNode169.Text = "Right$"
        TreeNode170.Name = "Node75"
        TreeNode170.Text = "RTrim"
        TreeNode171.Name = "Node76"
        TreeNode171.Text = "RTrim$"
        TreeNode172.Name = "Node77"
        TreeNode172.Text = "Space"
        TreeNode173.Name = "Node78"
        TreeNode173.Text = "Space$"
        TreeNode174.Name = "Node79"
        TreeNode174.Text = "StrComp"
        TreeNode175.Name = "Node80"
        TreeNode175.Text = "StrConv"
        TreeNode176.Name = "Node81"
        TreeNode176.Text = "String"
        TreeNode177.Name = "Node82"
        TreeNode177.Text = "String$"
        TreeNode178.Name = "Node83"
        TreeNode178.Text = "StringFromGUID"
        TreeNode179.Name = "Node84"
        TreeNode179.Text = "StrReverse"
        TreeNode180.Name = "Node85"
        TreeNode180.Text = "Trim"
        TreeNode181.Name = "Node86"
        TreeNode181.Text = "Trim$"
        TreeNode182.Name = "Node87"
        TreeNode182.Text = "UCase"
        TreeNode183.Name = "Node88"
        TreeNode183.Text = "UCase$"
        TreeNode184.Name = "Node13"
        TreeNode184.Text = "Text"
        TreeNode184.ToolTipText = "Text"
        TreeNode185.ImageIndex = 1
        TreeNode185.Name = "Node1"
        TreeNode185.SelectedImageIndex = 1
        TreeNode185.Text = "Functions"
        TreeNode185.ToolTipText = "Functions"
        Me.TrView_dbObjects.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode185})
        Me.TrView_dbObjects.ShowNodeToolTips = True
        Me.TrView_dbObjects.Size = New System.Drawing.Size(100, 298)
        Me.TrView_dbObjects.TabIndex = 0
        '
        'CntxtMnu_TrView_dbObjects_Tblqry
        '
        Me.CntxtMnu_TrView_dbObjects_Tblqry.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript, Me.CntxtMnu_TrView_dbObjects_Tblqry_GenDrop})
        Me.CntxtMnu_TrView_dbObjects_Tblqry.Name = "CntxtMnu_TrView_dbObjects"
        Me.CntxtMnu_TrView_dbObjects_Tblqry.Size = New System.Drawing.Size(170, 48)
        '
        'CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript
        '
        Me.CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript.Name = "CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript"
        Me.CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript.Size = New System.Drawing.Size(169, 22)
        Me.CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript.Text = "Generate Return All"
        '
        'CntxtMnu_TrView_dbObjects_Tblqry_GenDrop
        '
        Me.CntxtMnu_TrView_dbObjects_Tblqry_GenDrop.Name = "CntxtMnu_TrView_dbObjects_Tblqry_GenDrop"
        Me.CntxtMnu_TrView_dbObjects_Tblqry_GenDrop.Size = New System.Drawing.Size(169, 22)
        Me.CntxtMnu_TrView_dbObjects_Tblqry_GenDrop.Text = "Generate Drop"
        '
        'frm_Editor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(542, 373)
        Me.Controls.Add(Me.Split_ObjBrowser_And_Others)
        Me.Controls.Add(Me.MainToolStrip)
        Me.Controls.Add(Me.MainStatusStrip)
        Me.Controls.Add(Me.mnu_Main)
        Me.MainMenuStrip = Me.mnu_Main
        Me.MinimumSize = New System.Drawing.Size(550, 400)
        Me.Name = "frm_Editor"
        Me.Text = "Queries Editor"
        Me.CntxtMnu_TrView_dbObjects_DB.ResumeLayout(False)
        Me.ContextMnu_RText.ResumeLayout(False)
        Me.mnu_Main.ResumeLayout(False)
        Me.mnu_Main.PerformLayout()
        Me.MainStatusStrip.ResumeLayout(False)
        Me.MainStatusStrip.PerformLayout()
        Me.MainToolStrip.ResumeLayout(False)
        Me.MainToolStrip.PerformLayout()
        Me.Split_Doc_And_Output.Panel1.ResumeLayout(False)
        Me.Split_Doc_And_Output.Panel2.ResumeLayout(False)
        Me.Split_Doc_And_Output.ResumeLayout(False)
        Me.Tabs_Output.ResumeLayout(False)
        Me.TabPage_OutPutDGV.ResumeLayout(False)
        CType(Me.dgv_OutPut, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_OutPutTxt.ResumeLayout(False)
        Me.TabPage_OutPutTxt.PerformLayout()
        Me.Split_ObjBrowser_And_Others.Panel1.ResumeLayout(False)
        Me.Split_ObjBrowser_And_Others.Panel2.ResumeLayout(False)
        Me.Split_ObjBrowser_And_Others.ResumeLayout(False)
        Me.CntxtMnu_TrView_dbObjects_Tblqry.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Rtext_Doc As ColoringWords.DevRichTextBox
    Friend WithEvents mnu_Main As System.Windows.Forms.MenuStrip
    Friend WithEvents mnu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Connect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_SaveAs As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Save As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MainStatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents MainToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents btn_Exec As System.Windows.Forms.ToolStripButton
    Friend WithEvents mnu_Edit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Split_Doc_And_Output As System.Windows.Forms.SplitContainer
    Friend WithEvents Tabs_Output As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_OutPutDGV As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_OutPutTxt As System.Windows.Forms.TabPage
    Friend WithEvents txt_OutPut As System.Windows.Forms.TextBox
    Friend WithEvents dgv_OutPut As QueryEditor.DevDataGridView
    Friend WithEvents status_OutPutCount As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_Connection As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnu_Cut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Copy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Paste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Undo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Redo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_EditSep0 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu_Format As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_WordWrap As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Font As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents status_CurCol As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_CurTask As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents mnu_FileSep1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu_Open As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTips As System.Windows.Forms.ToolTip
    Friend WithEvents mnu_EditSep1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Split_ObjBrowser_And_Others As System.Windows.Forms.SplitContainer
    Friend WithEvents TrView_dbObjects As QueryEditor.DevTreeView
    Friend WithEvents ContextMnu_RText As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Cmnu_Undo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Cmnu_Redo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMnu_RText_Sep0 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Cmnu_Cut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Cmnu_Copy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Cmnu_Paste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_FileSep2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu_Export2ExcelByHTML As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolBar_Cut As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolBar_Save As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolBar_Sep1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolBar_Copy As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolBar_Paste As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolBar_Sep2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolBar_Connect As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolBar_Sep0 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolBar_Open As System.Windows.Forms.ToolStripButton
    Friend WithEvents mnu_Query As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Exec As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_QuerySep0 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu_Convert2Code As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_View As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_ObjectsBrowser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_ShowOutPutPanel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents status_CurLine As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Status_Ins_Ovr As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ContextMnu_RText_Sep1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Cmnu_EditorOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CntxtMnu_TrView_dbObjects_DB As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Cmnu_DB_Refresh As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Cmnu_DB_Connect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CntxtMnu_TrView_dbObjects_Tblqry As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CntxtMnu_TrView_dbObjects_TblQry_GenSelectALLScript As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CntxtMnu_TrView_dbObjects_Tblqry_GenDrop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Query_Parameters As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_File_NewQuery As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_FileSep0 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu_Output As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_ClearOutPut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_EditorOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Cmnu_SelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMnu_RText_Sep2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnu_SelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Replace As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Find As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_TutorialFeatures As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Export2ExcelByXML As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Export2ExcelByExcelApp As System.Windows.Forms.ToolStripMenuItem

End Class
