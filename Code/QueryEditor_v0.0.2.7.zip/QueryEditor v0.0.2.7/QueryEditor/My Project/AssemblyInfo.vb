﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Query Editor")> 
<Assembly: AssemblyDescription("An application helps you creating Queries for MS Access DataBases, it provieds plenty of features like Exploring DB schema , Coloring Keywords, Auto Completion , .......etc")> 
<Assembly: AssemblyCompany("URYICO")> 
<Assembly: AssemblyProduct("Query Editor")> 
<Assembly: AssemblyCopyright("GPL")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("8b3645b0-712a-457a-9dac-2e4dcb4961cb")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
