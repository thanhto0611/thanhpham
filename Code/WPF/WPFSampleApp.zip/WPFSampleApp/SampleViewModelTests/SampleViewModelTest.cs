﻿using WPFSampleModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.ObjectModel;
using WPFSampleBizLogic;
using System.ComponentModel;

namespace SampleViewModelTests
{
    
    
    /// <summary>
    ///This is a test class for SampleViewModelTest and is intended
    ///to contain all SampleViewModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SampleViewModelTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SampleViewModel Constructor
        ///</summary>
        [TestMethod()]
        public void SampleViewModelConstructorTest()
        {
            SampleViewModel target = new SampleViewModel();
            Assert.IsNotNull(target is SampleViewModel);
        }

        /// <summary>
        ///A test for CreateStudent
        ///</summary>
        [TestMethod()]
        [DeploymentItem("WPFSampleModel.dll")]
        public void CreateStudentTest()
        {
            SampleViewModel_Accessor target = new SampleViewModel_Accessor(); // TODO: Initialize to an appropriate value
            object expected = null; // TODO: Initialize to an appropriate value
            object actual;
            actual = target.CreateStudent();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for item_PropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("WPFSampleModel.dll")]
        public void item_PropertyChangedTest()
        {
            SampleViewModel_Accessor target = new SampleViewModel_Accessor(); // TODO: Initialize to an appropriate value
            object sender = null; // TODO: Initialize to an appropriate value
            PropertyChangedEventArgs e = null; // TODO: Initialize to an appropriate value
            target.item_PropertyChanged(sender, e);
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for LoadDepartments
        ///</summary>
        [TestMethod()]
        [DeploymentItem("WPFSampleModel.dll")]
        public void LoadDepartmentsTest()
        {
            SampleViewModel_Accessor target = new SampleViewModel_Accessor(); // TODO: Initialize to an appropriate value
            ObservableCollection<DepartmerntItem> expected = null; // TODO: Initialize to an appropriate value
            ObservableCollection<DepartmerntItem> actual;
            actual = target.LoadDepartments();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for LoadStudents
        ///</summary>
        [TestMethod()]
        [DeploymentItem("WPFSampleModel.dll")]
        public void LoadStudentsTest()
        {
            SampleViewModel_Accessor target = new SampleViewModel_Accessor(); // TODO: Initialize to an appropriate value
            ObservableCollection<StudentItem> expected = null; // TODO: Initialize to an appropriate value
            ObservableCollection<StudentItem> actual;
            actual = target.LoadStudents();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for SaveCurrentStudent
        ///</summary>
        [TestMethod()]
        public void SaveCurrentStudentTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            object expected = null; // TODO: Initialize to an appropriate value
            object actual;
            actual = target.SaveCurrentStudent();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for ValidateCurrentData
        ///</summary>
        [TestMethod()]
        [DeploymentItem("WPFSampleModel.dll")]
        public void ValidateCurrentDataTest()
        {
            SampleViewModel_Accessor target = new SampleViewModel_Accessor(); // TODO: Initialize to an appropriate value
            bool expected = false; // TODO: Initialize to an appropriate value
            bool actual;
            actual = target.ValidateCurrentData();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for CanCreateStudent
        ///</summary>
        [TestMethod()]
        public void CanCreateStudentTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            bool actual;
            actual = target.CanCreateStudent;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for CanSaveStudent
        ///</summary>
        [TestMethod()]
        public void CanSaveStudentTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            bool expected = false; // TODO: Initialize to an appropriate value
            bool actual;
            target.CanSaveStudent = expected;
            actual = target.CanSaveStudent;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for ConnectionString
        ///</summary>
        [TestMethod()]
        public void ConnectionStringTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            string actual;
            actual = target.ConnectionString;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for CreateNewStudent
        ///</summary>
        [TestMethod()]
        public void CreateNewStudentTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            CommandBase actual;
            actual = target.CreateNewStudent;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for CurrentStudent
        ///</summary>
        [TestMethod()]
        public void CurrentStudentTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            StudentItem expected = null; // TODO: Initialize to an appropriate value
            StudentItem actual;
            target.CurrentStudent = expected;
            actual = target.CurrentStudent;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for DbFactory
        ///</summary>
        [TestMethod()]
        public void DbFactoryTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            DataManager actual;
            actual = target.DbFactory;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Departments
        ///</summary>
        [TestMethod()]
        public void DepartmentsTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            ObservableCollection<DepartmerntItem> actual;
            actual = target.Departments;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for SaveStudent
        ///</summary>
        [TestMethod()]
        public void SaveStudentTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            CommandBase actual;
            actual = target.SaveStudent;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Students
        ///</summary>
        [TestMethod()]
        public void StudentsTest()
        {
            SampleViewModel target = new SampleViewModel(); // TODO: Initialize to an appropriate value
            ObservableCollection<StudentItem> actual;
            actual = target.Students;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}
