﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WPFSampleBizLogic.DataLayer;
using System.Data;

namespace WPFSampleBizLogic.DataFetcher
{
    public static class DepartmentFetcher
    {
        public static Department GetDepartment(string deptId, DataManager manager)
        {
            string sql = string.Format(@"select deptid, DepartmentName FROM DEPARTMENT WHERE deptid = '{0}'", deptId);
            DataTable dtresult = manager.GetTable(sql);
            if (dtresult.Rows.Count > 0)
            {
                return new Department { Name = dtresult.Rows[0][0].ToString(), Id = dtresult.Rows[0][1].ToString() };
            }
            return new Department();
        }

        public static IEnumerable<Department> GetDepartments(DataManager manager)
        {
            string sql = "select deptid, DepartmentName FROM DEPARTMENT";
            DataTable dtresult = manager.GetTable(sql);
            for (int i = 0; i < dtresult.Rows.Count; i++)
                yield return new Department { Id = dtresult.Rows[i][0].ToString(), Name = dtresult.Rows[i][1].ToString() };
        }
    }
}
