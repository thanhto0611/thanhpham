﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WPFSampleBizLogic.DataLayer;
using System.Data;
using System.Data.SqlClient;

namespace WPFSampleBizLogic.DataFetcher
{
    public static class StudentFetcher
    {
        public static Student GetStudent(string studentid, DataManager manager)
        {
            string sql = string.Format(@"select id, Name, Age, Salary,deptid  FROM STUDENT WHERE id = '{0}'", studentid);
            DataTable dtresult = manager.GetTable(sql);
            if (dtresult.Rows.Count > 0)
            {
                return new Student { Id = dtresult.Rows[0][0].ToString(), Name = dtresult.Rows[0][1].ToString(), Age = Convert.ToInt32(dtresult.Rows[0][2]), Salary = Convert.ToSingle(dtresult.Rows[0][3]), DeptId = dtresult.Rows[0][4].ToString() };
            }
            return new Student();
        }

        public static IEnumerable<Student> GetStudents(DataManager manager)
        {
            string sql = "select id, Name, Age, Salary,deptid  FROM STUDENT";
            DataTable dtresult = manager.GetTable(sql);
            for (int i = 0; i < dtresult.Rows.Count; i++)
                yield return new Student { Id = dtresult.Rows[i][0].ToString(), Name = dtresult.Rows[i][1].ToString(), Age = Convert.ToInt32(dtresult.Rows[i][2]), Salary = Convert.ToSingle(dtresult.Rows[i][3]), DeptId = dtresult.Rows[i][4].ToString() };
        }

        public static bool SaveStudent(Student student, DataManager manager)
        {
            string sql = string.Empty;
            if (string.IsNullOrEmpty(student.Id))
            {
                sql = "Insert into student Values('{0}', '{1}', {2}, {3}, '{4}')";
                student.Id = Guid.NewGuid().ToString();
            }
            else
            {
                sql = "Update student Set Id = '{0}', Name='{1}', Age={2}, Salary={3}, DeptId='{4}' WHERE Id={0}";
            }
            
            using (SqlCommand command = new SqlCommand(string.Format(sql, student.Id, student.Name, student.Age, student.Salary, student.DeptId)))
            {

                //SqlParameter param = new SqlParameter("@pid", Guid.NewGuid().ToString());
                //param.DbType = DbType.String;
                //command.Parameters.Add(param);
                //param = new SqlParameter("@name", student.Name);
                //command.Parameters.Add(param);
                //param = new SqlParameter("@age", student.Age);
                //param.SqlDbType = SqlDbType.Int;
                //command.Parameters.Add(param);
                //param = new SqlParameter("@salary", student.Salary);
                //param.SqlDbType = SqlDbType.Decimal;
                //command.Parameters.Add(param);
                //param = new SqlParameter("@deptid", student.DeptId);
                //command.Parameters.Add(param);
                command.Connection = manager.GetConnection();
                command.CommandType = CommandType.Text;
                command.ExecuteNonQuery();
                
                return true;
            }
        }
    }
}
