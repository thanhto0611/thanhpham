﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFSampleBizLogic.DataLayer
{
    public class Student
    {
        public string Name { get; set; }
        public string Id { get; set; }
        public int Age { get; set; }
        public float Salary { get; set; }
        public string DeptId { get; set; }
    }
}
