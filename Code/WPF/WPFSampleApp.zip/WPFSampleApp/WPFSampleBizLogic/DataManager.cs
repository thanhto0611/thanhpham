﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace WPFSampleBizLogic
{
    public class DataManager
    {
        public DataManager(string connectionstring)
        {
            this.ConnectionString = connectionstring;
        }
        public string ConnectionString { get; set; }

        public SqlConnection GetConnection()
        {
            SqlConnection scon = new SqlConnection(this.ConnectionString);
            scon.Open();
            return scon;
        }

        public DataTable GetTable(string sql)
        {
            SqlConnection scon = this.GetConnection();
            using (SqlCommand command = new SqlCommand(sql, scon))
            {
                return this.GetTable(command);
            }
        }
        public DataTable GetTable(SqlCommand cmd)
        {
            DataTable dtResult = new DataTable();
            SqlDataAdapter adpt = new SqlDataAdapter(cmd);
            adpt.Fill(dtResult);
            return dtResult;
        }

        
        
    }
}
