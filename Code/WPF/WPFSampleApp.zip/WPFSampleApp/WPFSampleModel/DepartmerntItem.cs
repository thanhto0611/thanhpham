﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFSampleModel
{
    public class DepartmerntItem : PropertyBase 
    {
        private string id;
        public string Id 
        { 
            get { return this.id; }
            set
            {
                this.OnPropertyChanging("Id");
                this.id = value;
                this.OnPropertyChanged("Id");
            }
        }
        private string department;
        public string Department
        {
            get { return this.department; }
            set
            {
                this.OnPropertyChanging("Department");
                this.department = value;
                this.OnPropertyChanged("Department");
            }
        }

        public override string ToString()
        {
            return this.Department;
        }
    }
}
