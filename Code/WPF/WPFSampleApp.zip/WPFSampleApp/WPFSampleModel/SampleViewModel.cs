﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using WPFSampleBizLogic;
using WPFSampleBizLogic.DataFetcher;
using WPFSampleBizLogic.DataLayer;
using System.Windows.Input;

namespace WPFSampleModel
{
    public class SampleViewModel : ViewModelBase
    {
        public SampleViewModel() { }

        public string ConnectionString
        {
            get
            {
                return ConfigurationSettings.AppSettings["connection"];
            }
        }
        private DataManager _manager;
        public DataManager DbFactory
        {
            get
            {
                if (this._manager == null)
                {
                    string connection = this.ConnectionString;
                    this._manager = new DataManager(connection);
                }
                return this._manager;
            }
        }
        private ObservableCollection<StudentItem> _students;
        public ObservableCollection<StudentItem> Students
        {
            get
            {
                if (this._students == null)
                    this._students = this.LoadStudents();
                return this._students;
                
            }
        }

        private ObservableCollection<StudentItem> LoadStudents()
        {
            ObservableCollection<StudentItem> items = new ObservableCollection<StudentItem>();

            var students = StudentFetcher.GetStudents(this.DbFactory);
            foreach (Student student in students)
            {
                StudentItem item = new StudentItem
                {
                    Id = student.Id,
                    Age = student.Age,
                    Name = student.Name,
                    Salary = student.Salary,
                    DeptId = student.DeptId,
                    Department = this.Departments.FirstOrDefault(e => e.Id.Equals(student.DeptId))
                };
                items.Add(item);
                //item.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(item_PropertyChanged);

            }
            return items;
            
        }

        void item_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            StudentItem item = sender as StudentItem;
            this.CanSaveStudent = item.IsValidData;
        }

        private ObservableCollection<DepartmerntItem> depts;
        public ObservableCollection<DepartmerntItem> Departments
        {
            get
            {
                if (this.depts == null)
                    this.depts = this.LoadDepartments();
                return this.depts;
            }
        }

        private ObservableCollection<DepartmerntItem> LoadDepartments()
        {
            ObservableCollection<DepartmerntItem> items = new ObservableCollection<DepartmerntItem>();

            var departments = DepartmentFetcher.GetDepartments(this.DbFactory);
            foreach (Department dept in departments)
            {
                items.Add(new DepartmerntItem
                {
                    Id = dept.Id,
                    Department=dept.Name
                });
            }
            return items;
        }

        private StudentItem currentStudent;

        public StudentItem CurrentStudent
        {
            get { return this.currentStudent; }
            set
            {
                this.OnPropertyChanging("CurrentStudent");
                this.currentStudent = value;
                this.OnPropertyChanged("CurrentStudent");
            }
        }

        private CommandBase createNewstudent;
        public CommandBase CreateNewStudent
        {
            get
            {
                
                this.createNewstudent = this.createNewstudent ?? new CommandBase(param => this.CreateStudent(), param => this.CanCreateStudent);
                return this.createNewstudent;
            }
        }

        private object CreateStudent()
        {
            this.CurrentStudent = new StudentItem();
            this.CurrentStudent.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(item_PropertyChanged);
            return this.CurrentStudent;
        }

        public bool CanCreateStudent
        {
            get { return true; }
        }

        private CommandBase savestudent;
        public CommandBase SaveStudent
        {
            get
            {
                if (savestudent == null)
                {
                    savestudent = new CommandBase(param => this.SaveCurrentStudent(), param => this.CanSaveStudent);
                }
                return savestudent;

            }
        }
        public bool cansave = true;
        public bool CanSaveStudent
        {
            get
            {
                return cansave;
            }
            set
            {
                this.OnPropertyChanging("CanSaveStudent");
                this.cansave = value;
                this.OnPropertyChanged("CanSaveStudent");
            }
        }

        private bool ValidateCurrentData()
        {
            if (this.CurrentStudent != null)
                return this.CurrentStudent.IsValidData;
            return false;
        }
        public object SaveCurrentStudent()
        {
            if (this.CanSaveStudent)
            {
                StudentFetcher.SaveStudent(new Student { Name = this.CurrentStudent.Name, Age = this.CurrentStudent.Age, DeptId = this.CurrentStudent.DeptId, Salary = this.CurrentStudent.Salary }, this.DbFactory);
                this.Students.Add(this.CurrentStudent);
            }
            return this.CurrentStudent;
        }
    }
}
