﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WPFSampleModel
{
    public class StudentItem : PropertyBase, IDataErrorInfo
    {
        private string id;
        public string Id
        {
            get { return this.id; }
            set
            {
                this.OnPropertyChanging("Id");
                this.id = value;
                this.OnPropertyChanged("Id");
            }
        }
        private string name;
        public string Name
        {
            get { return this.name; }
            set
            {
                this.OnPropertyChanging("Name");
                this.name = value;
                this.OnPropertyChanged("Name");
                this.OnPropertyChanged("IsValidData");
            }
        }
        private int age;
        public int Age
        {
            get { return this.age; }
            set
            {
                this.OnPropertyChanging("Age");
                this.age = value;
                this.OnPropertyChanged("Age");
                this.OnPropertyChanged("IsValidData");
            }
        }

        private float salary;
        public float Salary
        {
            get { return this.salary; }
            set
            {
                this.OnPropertyChanging("Salary");
                this.salary = value;
                this.OnPropertyChanged("Salary");
            }
        }
        private string deptid;
        public string DeptId
        {
            get { return this.deptid; }
            set
            {
                this.OnPropertyChanging("DeptId");
                this.deptid = value;
                this.OnPropertyChanged("DeptId");
            }
        }
        private DepartmerntItem department;
        public DepartmerntItem Department
        {
            get
            {
                return this.department;
            }
            set
            {
                this.OnPropertyChanging("Department");
                this.department = value;
                this.OnPropertyChanged("Department");
            }
        }
        public bool IsValidData
        {
            get
            {
                if (this.Age > 0 && this.Age < 100 && this.Name.Length > 0)
                    return true;

                return false;
            }
        }
        #region IDataErrorInfo Members

        public string Error
        {
            get { return string.Empty; }
        }

        public string this[string columnName]
        {
            get 
            {
                if (columnName.Equals("Age") && !(this.Age > 0 && this.Age < 100))
                    return "Age should be between 0 and 100";
                if (columnName.Equals("Name") && this.Name.Length <= 0)
                    return "Name should not be kept blank";

                return null;
            }
        }

        #endregion
    }
}
