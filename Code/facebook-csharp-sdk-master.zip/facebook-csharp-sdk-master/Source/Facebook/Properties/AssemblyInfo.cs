using System.Reflection;
using System.Runtime.InteropServices;
// Do not modify this file manually, use jakefile instead.
[assembly: AssemblyTitle("Facebook")]
[assembly: AssemblyDescription("Facebook C# SDK")]
[assembly: AssemblyCompany("The Outercurve Foundation")]
[assembly: AssemblyProduct("Facebook C# SDK")]
[assembly: AssemblyCopyright("Copyright (c) 2011, The Outercurve Foundation.")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("6.0.10")]
[assembly: AssemblyFileVersion("6.4.2")]
