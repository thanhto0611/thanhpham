Webshare - Readme
===================

For any information or support installing 
or using Webshare, visite the official website.
 
===============================================
 Please refer to http://www.webshare.fr/
