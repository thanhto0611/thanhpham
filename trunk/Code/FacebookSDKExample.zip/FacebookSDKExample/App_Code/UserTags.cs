﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserTags
/// </summary>
public class UserTags
{
    public long tag_uid { get; set; }

    public int x { get; set; }

    public int y { get; set; }

}