﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace BindingDP
{
public class A :DependencyObject
{
    public static readonly DependencyProperty HeightProperty = DependencyProperty.Register("Height", typeof(int), typeof(A),
            new FrameworkPropertyMetadata(0,
        FrameworkPropertyMetadataOptions.Inherits));

    public int Height
    {
        get
        {
            return (int)GetValue(HeightProperty);
        }
        set
        {
            SetValue(HeightProperty, value);
        }
    }

    public B BObject { get; set; }
}

public class B : DependencyObject
{
    public static readonly DependencyProperty HeightProperty;

    static B()
    {
        HeightProperty = A.HeightProperty.AddOwner(typeof(B), new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.Inherits));
    }
    public int Height
    {
        get
        {
            return (int)GetValue(HeightProperty);
        }
        set
        {
            SetValue(HeightProperty, value);
        }
    }
}
}
