﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace BindingDP
{
    /// <summary>
    /// Interaction logic for MyCustomUC.xaml
    /// </summary>
    public partial class MyCustomUC : UserControl
    {
        public MyCustomUC()
        {
            InitializeComponent();
            SetValue(ObserverPropertyKey, new ObservableCollection<Button>());
            //lstEvents.DataContext = this.Observer;
        }

        public static readonly DependencyPropertyKey ObserverPropertyKey = DependencyProperty.RegisterReadOnly("Observer", typeof(ObservableCollection<Button>), typeof(MyCustomUC),
                                                                new FrameworkPropertyMetadata(new ObservableCollection<Button>()));

        public static readonly DependencyProperty ObserverProperty = ObserverPropertyKey.DependencyProperty;

        public ObservableCollection<Button> Observer
        {
            get
            {
                return (ObservableCollection<Button>)GetValue(ObserverProperty);
            }
        }

        static FrameworkPropertyMetadata propertymetadata = new FrameworkPropertyMetadata("Comes as Default",
                                                                                   FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                                                                                   new PropertyChangedCallback(MyCustom_PropertyChanged),
                                                                                   new CoerceValueCallback(MyCustom_CoerceValue),
                                                                                   false,
                                                                                   UpdateSourceTrigger.PropertyChanged);

        public static readonly DependencyProperty MyCustomProperty = DependencyProperty.Register("MyCustom", typeof(string), typeof(MyCustomUC),
                                                                                                propertymetadata,
                                                                                                new ValidateValueCallback(MyCustom_Validate));



        private static void MyCustom_PropertyChanged(DependencyObject dobj, DependencyPropertyChangedEventArgs e)
        {
            //To be called whenever the DP is changed.
            
            //Observer.Add(string.Format("Property changed is fired : OldValue {0} NewValue : {1}", e.OldValue, e.NewValue));
        }

        private static object MyCustom_CoerceValue(DependencyObject dobj, object Value)
        {
            //called whenever dependency property value is reevaluated. The return value is the 
            //latest value set to the dependency property
            //Observer.Add(string.Format("CoerceValue is fired : Value {0}", Value));
            return Value;
        }

        private static bool MyCustom_Validate(object Value)
        {
            //Custom validation block which takes in the value of DP
            //Returns true / false based on success / failure of the validation
            //Observer.Add(string.Format("DataValidation is Fired : Value {0}", Value));
          

            return true;
        }
        public string MyCustom
        {
            get
            {
                return this.GetValue(MyCustomProperty) as string;
            }
            set
            {
                this.SetValue(MyCustomProperty, value);
            }
        }

    }
}
