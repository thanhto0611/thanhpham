﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BindingDP
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
        public static readonly DependencyProperty IsValuePassedProperty = DependencyProperty.RegisterAttached("IsValuePassed", typeof(bool), typeof(Window1),
            new FrameworkPropertyMetadata(new PropertyChangedCallback(IsValuePassed_Changed)));

        public static void SetIsValuePassed(DependencyObject obj, bool value)
        {
            obj.SetValue(IsValuePassedProperty, value);
        }
        public static bool GetIsValuePassed(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsValuePassedProperty);
        }

        public static void IsValuePassed_Changed(DependencyObject obj, DependencyPropertyChangedEventArgs e)
        {
            MessageBox.Show("Value passed");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1.SetIsValuePassed(this, !(bool)this.GetValue(IsValuePassedProperty));
        }
    }
}
